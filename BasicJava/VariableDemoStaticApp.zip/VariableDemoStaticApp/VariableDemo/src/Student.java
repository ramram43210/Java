public class Student
{
	String name; // instance variable
	int age; // instance variable
	
	static int SchoolCode = 1000; // Static Variable
	
	void printInstanceAndStaticVariables()
	{
		System.out.println("name : "+ name);
		System.out.println("age : "+ age);
		System.out.println("SchoolCode : "+ SchoolCode);
		System.out.println("**********************");
	}
}
