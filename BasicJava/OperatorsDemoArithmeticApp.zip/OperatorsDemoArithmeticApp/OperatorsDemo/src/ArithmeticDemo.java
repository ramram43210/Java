class ArithmeticDemo
{

	public static void main(String[] args)
	{

		int addedValue = 1 + 2;
		System.out.println("1 + 2 = " + addedValue);

		int subtractedValue = 2 - 1;
		System.out.println("2 - 1 = " + subtractedValue);

		int multipliedValue = 2 * 2;
		System.out.println("2 * 2 = " + multipliedValue);

		int diviedValue = 4 / 2;
		System.out.println("4 / 2 = " + diviedValue);

		int remainderValue = 5 % 2;
		System.out.println("5 % 2 = " + remainderValue);
		
		String firstString = "Hi";
        String secondString = " Welcome John.";
        String thirdString = firstString+secondString;
        System.out.println(thirdString);
		

	}
}