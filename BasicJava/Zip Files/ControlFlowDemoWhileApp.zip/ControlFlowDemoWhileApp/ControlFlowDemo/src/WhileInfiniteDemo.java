public class WhileInfiniteDemo
{
	public static void main(String[] args)
	{
		/*
		 * We can implement an infinite loop using the while statement
		 */
		while (true)
		{
			System.out.println("hello");
		}
	}
}