class WhileDemo
{
	public static void main(String[] args)
	{
		int count = 1;
		while (count < 20)
		{
			System.out.println("Count is: " + count);
			count++;
		}
	}
}