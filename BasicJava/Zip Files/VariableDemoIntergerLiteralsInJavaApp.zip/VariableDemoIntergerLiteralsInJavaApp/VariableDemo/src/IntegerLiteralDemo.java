public class IntegerLiteralDemo
{

	public static void main(String[] args)
	{

		int num = 10;

		System.out.println("num : " + num);

		num = 010;

		System.out.println("num : " + num);

		num = 0x10;

		System.out.println("num : " + num);

		num = 0b1010;

		System.out.println("num : " + num);

		long number = 599L;

		System.out.println("number : " + number);

	}
}
