package mypack;

public class A
{

	public void message()
	{
		System.out.println("Class A messgage has been called.....");

	}

}
