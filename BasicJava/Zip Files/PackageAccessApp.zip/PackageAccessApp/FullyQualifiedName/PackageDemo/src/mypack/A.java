package mypack;

public class A
{

	public void message()
	{
		System.out.println("mypack Class A messgage method has been called.....");

	}

}
