/**
 * The HelloWorldApp class implements an application that simply prints
 * "Hello World!" to standard output.
 */
class HelloWorldApp
{
	public static void main(String[] args)
	{
		/* Print Hello World! */
		System.out.println("Hello World!"); // Display the string.
	}
}