public interface Employee
{

}
