class ControlFlowDemo
{
	public static void main(String[] args)
	{
		boolean flag = false;
		if (flag)
		{
			System.out.println("flag is true,inside if block.");
		}
		else
		{
			System.out.println("flag is false,inside else block.");
		}

	}
}