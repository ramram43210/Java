public class EmployeeDemoTest
{

	public static void main(String[] args)
	{
		/*
		 * Invokes the no-argument constructor to create a new Employee object
		 * called employee.
		 */
		Employee employee = new Employee();
		System.out.println("Name : " + employee.name);
		System.out.println("Age  : " + employee.age);

	}

}
