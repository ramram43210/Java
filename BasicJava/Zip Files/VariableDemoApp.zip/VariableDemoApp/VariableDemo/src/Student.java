
public class Student
{
	String name; //instance variable  
	
	static int schoolCode=1000; //static variable
	
	public void eat()
	{
		int numberOfBiscuts = 10; //local variable
		System.out.println("has eaten " + numberOfBiscuts + " Biscuts");
	}
	
}
