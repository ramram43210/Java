public class Student
{
	/*
	 * public modifier � the field is accessible from all classes.
	 */
	public String name;
	
	/*
	 * private modifier�the field is accessible only within its own class.
	 */
	private int age;

}