public class StudentDemoTest
{

	public static void main(String[] args)
	{
		Student student = new Student();
		student.name = "Dave";
		student.age = 23;
	}

}
