public class IntegerLiteralDemo
{

	public static void main(String[] args)
	{

		boolean flag = true;

		System.out.println("flag : " + flag);

		boolean isSmartTv = false;

		System.out.println("isSmartTv : " + isSmartTv);
	}
}
