class AssignmentOperatorDemo1
{
	public static void main(String[] args)
	{

		int a = 5;
		int b = 2;

		/*
		 * Assigns value from right side operands to left side operand.
		 */
		a = b;

		System.out.println("a = " + a);

	}
}