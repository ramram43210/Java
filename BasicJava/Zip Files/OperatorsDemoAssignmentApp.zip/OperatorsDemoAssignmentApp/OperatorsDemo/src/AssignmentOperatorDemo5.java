class AssignmentOperatorDemo5
{
	public static void main(String[] args)
	{

		int a = 5;
		int b = 2;

		/*
		 * Adds right operand to the left operand and assign the result to left.
		 * 
		 * same as a=a/b
		 */
		a /= b;

		System.out.println("a = " + a);

	}
}