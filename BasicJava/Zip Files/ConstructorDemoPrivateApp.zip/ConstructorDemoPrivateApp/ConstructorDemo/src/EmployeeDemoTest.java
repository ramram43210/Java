public class EmployeeDemoTest
{

	public static void main(String[] args)
	{

		Employee employeeObject1 = new Employee();
		System.out.println("Name : " + employeeObject1.getName());
		System.out.println("Age  : " + employeeObject1.getAge());

	}

}
