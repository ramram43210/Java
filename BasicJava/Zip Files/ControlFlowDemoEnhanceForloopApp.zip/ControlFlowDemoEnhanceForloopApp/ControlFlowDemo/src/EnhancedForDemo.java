class EnhancedForDemo
{
	public static void main(String[] args)
	{

		String[] strArray =
		{ "Apple", "Ball", "Cat", "Dog" };

		/*
		 * Using foreach loop getting each element
		 * from strArray.
		 */
		for (String element : strArray)
		{
			System.out.println(element);
		}
	}
}