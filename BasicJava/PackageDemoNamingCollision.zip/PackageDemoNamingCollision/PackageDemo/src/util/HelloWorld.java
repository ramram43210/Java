package util;

public class HelloWorld
{

	public static void main(String[] args)
	{
		System.out.println("Hello world Program of 'util' Package....");

	}

}
