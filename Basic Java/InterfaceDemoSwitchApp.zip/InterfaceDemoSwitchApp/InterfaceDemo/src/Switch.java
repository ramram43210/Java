/**
 * An interface is a group of related methods with empty bodies.
 */
public interface Switch
{
	void switchOn();

	void switchOff();
}
