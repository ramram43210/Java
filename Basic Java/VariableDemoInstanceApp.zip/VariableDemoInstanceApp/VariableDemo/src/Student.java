public class Student
{
	String name; // instance variable
	int age; // instance variable
	
	void printInstanceVariable()
	{
		System.out.println("name : "+ name);
		System.out.println("age : "+ age);
		System.out.println("**********************");
	}
}
