public class IntegerLiteralDemo
{

	public static void main(String[] args)
	{

		int number = 901_306_555;

		System.out.println("number : " + number);

		int octalLiteral = 045_23;

		System.out.println("octalLiteral : " + octalLiteral);

		int hexadecimalLiteral = 0x55_21;

		System.out.println("hexadecimalLiteral : " + hexadecimalLiteral);

		int binaryLiteral = 0b1000_1001;

		System.out.println("binaryLiteral : " + binaryLiteral);

	}
}
