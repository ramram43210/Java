public class PersonDemo
{
	public static void main(String[] args)
	{

		Person peter = new Person();
		/*
		 * Setting Attributes/Properties/Characteristics.
		 */
		peter.name = "Peter";
		peter.age = 53;

		peter.displayMsg();

	}

}
