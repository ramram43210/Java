class ComparisionDemo
{
	public static void main(String[] args)
	{
		int value5 = 5;
		int value10 = 10;
		
		if (value5 == value10)
		{
			System.out.println("value5 == value10");
		}
		if (value5 != value10)
		{
			System.out.println("value5 != value10");
		}
		if (value5 > value10)
		{
			System.out.println("value5 > value10");
		}
		if (value5 < value10)
		{
			System.out.println("value5 < value10");
		}
		if (value5 <= value10)
		{
			System.out.println("value5 <= value10");
		}
		if (value5 >= value10)
		{
			System.out.println("value5 >= value10");
		}

	}
}