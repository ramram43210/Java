class PrePostDemo2
{
	public static void main(String[] args)
	{
		int i = 5;

		int j = ++i;

		System.out.println("j : " + j);

		System.out.println("i : " + i);

	}
}