class PrePostDemo1
{
	public static void main(String[] args)
	{
		int i = 5;
		i++;
		// prints 6
		System.out.println(i);
		++i;
		// prints 7
		System.out.println(i);
		
	}
}