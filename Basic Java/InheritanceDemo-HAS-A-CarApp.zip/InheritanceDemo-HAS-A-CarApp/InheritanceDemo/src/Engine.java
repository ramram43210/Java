public class Engine
{
	public void start()
	{

		System.out.println("Engine Started:");

	}

	public void stop()
	{

		System.out.println("Engine Stopped:");

	}
}
