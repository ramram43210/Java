class ArrayDemo
{
	public static void main(String[] args)
	{
		int[][] intArray = {{10,20,30},{100,200,300}};
		
		System.out.println("Element at intArray[0][0] : " + intArray[0][0]);
		System.out.println("Element at intArray[0][1] : " + intArray[0][1]);
		System.out.println("Element at intArray[0][2] : " + intArray[0][2]);

		System.out.println();

		System.out.println("Element at intArray[1][0] : " + intArray[1][0]);
		System.out.println("Element at intArray[1][1] : " + intArray[1][1]);
		System.out.println("Element at intArray[1][2] : " + intArray[1][2]);

	}
}