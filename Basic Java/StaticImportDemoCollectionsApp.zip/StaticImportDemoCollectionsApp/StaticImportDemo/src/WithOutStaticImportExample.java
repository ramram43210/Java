import java.util.Collections;

/**
 * 
 * Example of with out Static import.
 *
 */
public class WithOutStaticImportExample
{

	public static void main(String[] args)
	{

		System.out.println("Empty List : " + Collections.EMPTY_LIST);
		System.out.println("Empty Set : " + Collections.emptySet());

	}

}
