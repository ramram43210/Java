/**
 * SoftwareEngineer class is the sub class which
 * extends Employee Super class.
 */
public class SoftwareEngineer extends Employee
{
	int bonus = 30000;
	
	public void talkAboutJava()
	{
		System.out.println("Can talk about Java");
	}
}
