/**
 * Employee class is the Super class.
 */
public class Employee
{
	int salary = 50000;

	public void run()
	{
		System.out.println("Can run");
	}

	public void walk()
	{
		System.out.println("Can Walk");
	}

}