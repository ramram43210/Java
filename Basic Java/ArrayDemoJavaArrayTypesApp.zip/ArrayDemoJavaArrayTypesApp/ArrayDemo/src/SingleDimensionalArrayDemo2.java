public class SingleDimensionalArrayDemo2
{

	public static void main(String[] args)
	{
		int intArray[] =
		{ 51, 61, 89 };// declaration, instantiation and initialization

		for (int i = 0; i < intArray.length; i++)
		{
			System.out.println("Element at index position " + i + " : "
					+ intArray[i]);
		}
	}

}
