
public class StringLiteralDemo
{

	public static void main(String[] args)
	{

		String quitMsg = "Are you sure you want to quit?";

		System.out.println("quitMsg : " + quitMsg);

		String password = "swordfish";

		System.out.println("password : " + password);

		String value = "Ram asked, \"How are you?\"";

		System.out.println("value : " + value);

		System.out.println("hi,\n Welcome\n");

		String title = "Sams Teach Yourself Java While You Sleep\u2122";

		System.out.println("title : " + title);

	}

}
