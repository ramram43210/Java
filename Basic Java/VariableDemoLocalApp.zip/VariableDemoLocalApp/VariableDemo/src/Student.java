public class Student
{
	public int getTotalMarks()
	{
		int marksScoredInScience = 80; // Local Variable
		int marksScoredInEnglish = 90; // Local Variable
		int totalMarks = marksScoredInScience 
				              + marksScoredInEnglish; // Local Variable
		return totalMarks;
	}
}
