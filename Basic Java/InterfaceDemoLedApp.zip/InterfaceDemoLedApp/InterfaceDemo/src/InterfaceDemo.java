public class InterfaceDemo
{

	public static void main(String[] args)
	{
		Person peter = new Person("Peter",28);
		peter.switchOnTheTV();
		System.out.println("-----------------------------------------------");
		peter.switchOffTheTV();
	}
}
