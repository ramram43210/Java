public class CharLiteralDemo
{

	public static void main(String[] args)
	{

		char char_a = 'a';
		System.out.println("char_a : " + char_a);

		char char_3 = '3';
		System.out.println("char_3 : " + char_3);

		char singleQuotationMark = '\'';

		System.out.println("singleQuotationMark : " + singleQuotationMark);

		char doubleQuotationMark = '\"';

		System.out.println("doubleQuotationMark : " + doubleQuotationMark);

		char captialA = '\u0041';

		System.out.println("captialA : " + captialA);

		char digitZero = '\u0030';

		System.out.println("digitZero : " + digitZero);

	}
}
